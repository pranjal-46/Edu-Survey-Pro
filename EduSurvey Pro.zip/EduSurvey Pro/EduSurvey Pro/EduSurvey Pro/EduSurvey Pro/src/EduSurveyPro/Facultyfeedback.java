/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package EduSurveyPro;

/**
 *
 * @author WAJAHAT
 */
public class Facultyfeedback {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        log_in ob=new log_in();
        ob.setVisible(true);
        ob.setLocation(300, 200);
    }
}
